<?php 

$host = "localhost";
$username = "root";
$password = "24682468";
$dbname = "crud_db";

$con = mysqli_connect($host, $username, $password, $dbname);

if (!$con) {
	die("Connection failed" . mysqli_errno($con));
}

 ?>